# Student Dashboard

React + Vite frontend project for the College Student Management System.

## Features

- Header with college name and application title
- StudentProfile reusable component using props
- SubjectList using an array and `map()`
- Dynamic attendance percentage
- Eligible / Not Eligible conditional rendering
- ExamDetails component
- Footer component
- Bonus StudentCard component
- View Profile button
- Responsive CSS styling
- Organized `components` folder

## Run

Open the terminal inside this folder:

```bash
npm install
npm run dev
```

Open the URL shown by Vite, normally:

```text
http://localhost:5173
```

## Project Structure

```text
student-dashboard/
├── src/
│   ├── components/
│   │   ├── Attendance.jsx
│   │   ├── ExamDetails.jsx
│   │   ├── Footer.jsx
│   │   ├── Header.jsx
│   │   ├── StudentCard.jsx
│   │   ├── StudentProfile.jsx
│   │   └── SubjectList.jsx
│   ├── App.jsx
│   ├── main.jsx
│   └── styles.css
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

## Notes

The project is ready to run after `npm install`. The sample student data can be changed in `src/App.jsx`.
