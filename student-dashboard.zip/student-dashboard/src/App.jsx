import Header from "./components/Header";
import StudentProfile from "./components/StudentProfile";
import SubjectList from "./components/SubjectList";
import Attendance from "./components/Attendance";
import ExamDetails from "./components/ExamDetails";
import StudentCard from "./components/StudentCard";
import Footer from "./components/Footer";

const student = {
  name: "Swetha Thakur",
  rollNumber: "23CS001",
  branch: "Computer Science Engineering",
  year: "3rd Year",
};

const subjects = [
  { name: "Data Structures", code: "23CS301", faculty: "Dr. Kumar" },
  { name: "Database Management Systems", code: "23CS302", faculty: "Dr. Priya" },
  { name: "Computer Networks", code: "23CS303", faculty: "Dr. Ravi" },
  { name: "Software Engineering", code: "23CS304", faculty: "Dr. Madan" },
  { name: "Artificial Intelligence", code: "23CS305", faculty: "Dr. Anitha" },
];

const exams = [
  { subject: "Data Structures", date: "10 October 2026", time: "10:00 AM" },
  { subject: "DBMS", date: "13 October 2026", time: "10:00 AM" },
  { subject: "Computer Networks", date: "16 October 2026", time: "10:00 AM" },
];

const students = [
  { name: "Swetha Thakur", rollNumber: "23CS001", branch: "CSE", year: "3rd Year", attendance: 92 },
  { name: "Rahul Kumar", rollNumber: "23CS002", branch: "CSE", year: "3rd Year", attendance: 78 },
  { name: "Anjali Rao", rollNumber: "23CS003", branch: "CSE", year: "3rd Year", attendance: 65 },
];

function App() {
  const attendance = 92;

  return (
    <div className="app">
      <Header
        collegeName="ABC Institute of Technology"
        title="Student Management Dashboard"
      />

      <main className="dashboard-container">
        <section className="welcome-section">
          <div>
            <p className="eyebrow">STUDENT PORTAL</p>
            <h1>Student Management Dashboard</h1>
            <p>View your academic profile, subjects, attendance, and examination information.</p>
          </div>
          <div className="welcome-badge">Academic Year 2026–27</div>
        </section>

        <section className="top-grid">
          <StudentProfile student={student} />
          <Attendance percentage={attendance} />
        </section>

        <section className="content-grid">
          <SubjectList subjects={subjects} />
          <ExamDetails exams={exams} />
        </section>

        <section className="student-section">
          <div className="section-heading">
            <div>
              <p className="eyebrow">BONUS</p>
              <h2>Student Cards</h2>
            </div>
            <span>Reusable component + conditional rendering</span>
          </div>

          <div className="student-cards">
            {students.map((item) => (
              <StudentCard key={item.rollNumber} student={item} />
            ))}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

export default App;