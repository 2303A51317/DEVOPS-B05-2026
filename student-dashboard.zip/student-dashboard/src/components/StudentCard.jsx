import { useState } from "react";

function StudentCard({ student }) {
  const [viewProfile, setViewProfile] = useState(false);
  const eligible = student.attendance >= 75;

  return (
    <article className="student-card">
      <div className="mini-avatar">{student.name.charAt(0)}</div>
      <div className="student-card-info">
        <h3>{student.name}</h3>
        <p>{student.rollNumber} · {student.branch} · {student.year}</p>
        <span className={`mini-status ${eligible ? "eligible-text" : "not-eligible-text"}`}>
          {eligible ? "Eligible" : "Not Eligible"} · {student.attendance}% attendance
        </span>
      </div>
      <button onClick={() => setViewProfile(!viewProfile)}>
        {viewProfile ? "Hide Profile" : "View Profile"}
      </button>

      {viewProfile && (
        <div className="profile-popup">
          <strong>{student.name}</strong>
          <span>Roll Number: {student.rollNumber}</span>
          <span>Attendance: {student.attendance}%</span>
        </div>
      )}
    </article>
  );
}

export default StudentCard;