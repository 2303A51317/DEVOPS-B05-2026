function Header({ collegeName, title }) {
  return (
    <header className="header">
      <div className="header-inner">
        <div className="logo">ABC</div>
        <div>
          <p className="college-name">{collegeName}</p>
          <p className="app-title">{title}</p>
        </div>
      </div>
      <div className="header-status">
        <span className="status-dot"></span>
        Student Portal
      </div>
    </header>
  );
}

export default Header;