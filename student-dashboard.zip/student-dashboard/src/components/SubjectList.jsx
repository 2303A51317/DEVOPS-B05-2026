function SubjectList({ subjects }) {
  return (
    <article className="card">
      <div className="card-title-row">
        <div>
          <p className="eyebrow">ACADEMICS</p>
          <h2>Subjects</h2>
        </div>
        <span className="count-badge">{subjects.length} Subjects</span>
      </div>

      <div className="subject-list">
        {subjects.map((subject) => (
          <div className="subject-item" key={subject.code}>
            <div className="subject-icon">📚</div>
            <div className="subject-main">
              <strong>{subject.name}</strong>
              <span>{subject.code} · {subject.faculty}</span>
            </div>
            <span className="arrow">→</span>
          </div>
        ))}
      </div>
    </article>
  );
}

export default SubjectList;