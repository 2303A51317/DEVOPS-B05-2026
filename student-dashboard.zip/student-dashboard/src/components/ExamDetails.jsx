function ExamDetails({ exams }) {
  return (
    <article className="card">
      <div className="card-title-row">
        <div>
          <p className="eyebrow">EXAMINATION</p>
          <h2>Upcoming Exams</h2>
        </div>
        <span className="calendar-icon">📅</span>
      </div>

      <div className="exam-list">
        {exams.map((exam) => (
          <div className="exam-item" key={`${exam.subject}-${exam.date}`}>
            <div className="date-box">
              <strong>{exam.date.split(" ")[0]}</strong>
              <span>{exam.date.split(" ")[1].slice(0, 3)}</span>
            </div>
            <div>
              <strong>{exam.subject}</strong>
              <span>{exam.date} · {exam.time}</span>
            </div>
          </div>
        ))}
      </div>
    </article>
  );
}

export default ExamDetails;