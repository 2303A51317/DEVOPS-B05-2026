function Attendance({ percentage }) {
  const eligible = percentage >= 75;

  return (
    <article className="card attendance-card">
      <div>
        <p className="eyebrow">ATTENDANCE</p>
        <h2>Overall Attendance</h2>
      </div>

      <div className="attendance-circle" style={{ "--attendance": `${percentage * 3.6}deg` }}>
        <div className="attendance-inner">
          <strong>{percentage}%</strong>
          <span>Present</span>
        </div>
      </div>

      <div className={`eligibility ${eligible ? "eligible" : "not-eligible"}`}>
        <span>{eligible ? "✓" : "!"}</span>
        {eligible ? "Eligible for examinations" : "Not Eligible for examinations"}
      </div>

      <p className="attendance-note">
        Minimum required attendance: <strong>75%</strong>
      </p>
    </article>
  );
}

export default Attendance;