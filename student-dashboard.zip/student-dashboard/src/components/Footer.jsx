function Footer() {
  return (
    <footer className="footer">
      <p>© 2026 ABC Institute of Technology. All rights reserved.</p>
      <p>Student Management System</p>
    </footer>
  );
}

export default Footer;