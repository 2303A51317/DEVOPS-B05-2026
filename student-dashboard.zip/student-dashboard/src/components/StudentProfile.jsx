function StudentProfile({ student }) {
  return (
    <article className="card profile-card">
      <div className="card-title-row">
        <div>
          <p className="eyebrow">PROFILE</p>
          <h2>Student Profile</h2>
        </div>
        <div className="avatar">{student.name.charAt(0)}</div>
      </div>

      <div className="profile-info">
        <div>
          <span>Name</span>
          <strong>{student.name}</strong>
        </div>
        <div>
          <span>Roll Number</span>
          <strong>{student.rollNumber}</strong>
        </div>
        <div>
          <span>Branch</span>
          <strong>{student.branch}</strong>
        </div>
        <div>
          <span>Year</span>
          <strong>{student.year}</strong>
        </div>
      </div>
    </article>
  );
}

export default StudentProfile;