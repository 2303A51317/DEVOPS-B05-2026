﻿// Central catalog of books. In a real store this would come from an API,
// but a static array is enough to demonstrate props-based data flow.
const books = [
  { id: 1, title: "The Silent Orchard", author: "Meera Nair", price: 349, category: "Fiction", rating: 4.5, spineColor: "#8C5A3C", blurb: "A quiet family drama set across three generations of apple farmers." },
  { id: 2, title: "Ledger of Small Gods", author: "Thomas Kell", price: 499, category: "Fantasy", rating: 4.8, spineColor: "#3E5C4C", blurb: "Minor deities keep the accounts of a crumbling empire." },
  { id: 3, title: "Signals from Kepler", author: "Ananya Rao", price: 425, category: "Sci-Fi", rating: 4.2, spineColor: "#2F4B5E", blurb: "A radio astronomer intercepts a message that shouldn't exist." },
  { id: 4, title: "The Cartographer's Debt", author: "Wren Alcott", price: 375, category: "Mystery", rating: 4.6, spineColor: "#6B3F4E", blurb: "An old map leads to a decades-old disappearance." },
  { id: 5, title: "Notes on Becoming", author: "Farah Idris", price: 299, category: "Biography", rating: 4.9, spineColor: "#B8862E", blurb: "A candid memoir about building a life from scratch, twice." },
  { id: 6, title: "The Marigold Express", author: "Priya Deshmukh", price: 249, category: "Children", rating: 4.7, spineColor: "#C0592F", blurb: "A runaway train, a curious fox, and a very late birthday." },
  { id: 7, title: "Salt and Static", author: "Diego Marín", price: 399, category: "Sci-Fi", rating: 4.1, spineColor: "#3E5C4C", blurb: "A coastal town loses electricity, then loses its ghosts too." },
  { id: 8, title: "The Understudy's Table", author: "Meera Nair", price: 329, category: "Fiction", rating: 4.3, spineColor: "#8C5A3C", blurb: "Two rival chefs share a kitchen, a lease, and a secret." },
  { id: 9, title: "A Field Guide to Losing", author: "Sam Okoro", price: 359, category: "Mystery", rating: 4.4, spineColor: "#6B3F4E", blurb: "A private investigator who only takes cases she can't solve." },
];

export default books;

export const categories = [
  "All",
  ...Array.from(new Set(books.map((book) => book.category))),
];
