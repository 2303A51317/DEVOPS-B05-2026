﻿import Rating from "../Rating/Rating.jsx";
import "./BookCard.css";

function BookCard({ book, onViewDetails }) {
  const { title, author, price, category, rating, spineColor, blurb } = book;
  const initial = title.charAt(0);

  return (
    <article className="book-card">
      <div className="book-card__cover" style={{ background: spineColor }}>
        <span className="book-card__initial">{initial}</span>
        <span className="book-card__category-tag">{category}</span>
      </div>

      <div className="book-card__body">
        <h3 className="book-card__title">{title}</h3>
        <p className="book-card__author">{author}</p>
        <p className="book-card__blurb">{blurb}</p>

        <Rating value={rating} />

        <div className="book-card__footer">
          <span className="book-card__price">₹{price}</span>
          <div className="book-card__actions">
            <button type="button" className="book-card__btn book-card__btn--ghost" onClick={() => onViewDetails(book)}>View details</button>
            <button type="button" className="book-card__btn book-card__btn--solid">Buy now</button>
          </div>
        </div>
      </div>
    </article>
  );
}

export default BookCard;
