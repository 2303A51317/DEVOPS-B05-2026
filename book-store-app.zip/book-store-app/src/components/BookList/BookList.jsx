﻿import BookCard from "../BookCard/BookCard.jsx";
import "./BookList.css";

function BookList({ books, onViewDetails }) {
  if (books.length === 0) {
    return (
      <div className="book-list__empty">
        <p className="book-list__empty-title">No Books Found</p>
        <p className="book-list__empty-text">Try a different title, author, or category.</p>
      </div>
    );
  }

  return (
    <>
      <p className="book-list__status">
        Book Found — showing {books.length} {books.length === 1 ? "title" : "titles"}
      </p>
      <div className="book-list">
        {books.map((book) => (
          <BookCard key={book.id} book={book} onViewDetails={onViewDetails} />
        ))}
      </div>
    </>
  );
}

export default BookList;
