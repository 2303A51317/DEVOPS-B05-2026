﻿import "./SearchBar.css";

function SearchBar({ value, onChange }) {
  return (
    <div className="search-bar">
      <svg className="search-bar__icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
        <circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" strokeWidth="2" />
        <line x1="16.2" y1="16.2" x2="21" y2="21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      </svg>
      <input
        type="text"
        className="search-bar__input"
        placeholder="Search by title or author"
        value={value}
        onChange={(event) => onChange(event.target.value)}
        aria-label="Search books by title or author"
      />
      {value && (
        <button type="button" className="search-bar__clear" onClick={() => onChange("")} aria-label="Clear search">×</button>
      )}
    </div>
  );
}

export default SearchBar;
