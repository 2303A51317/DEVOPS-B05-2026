﻿import "./Category.css";

function Category({ categories, activeCategory, onSelect }) {
  return (
    <nav className="category" aria-label="Book categories">
      <ul>
        {categories.map((category) => (
          <li key={category}>
            <button
              type="button"
              className={"category__chip" + (category === activeCategory ? " category__chip--active" : "")}
              onClick={() => onSelect(category)}
              aria-pressed={category === activeCategory}
            >
              {category}
            </button>
          </li>
        ))}
      </ul>
    </nav>
  );
}

export default Category;
