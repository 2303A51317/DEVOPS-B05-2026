﻿import "./Header.css";

const NAV_LINKS = ["Home", "Categories", "New Arrivals", "About"];

function Header() {
  return (
    <header className="header">
      <div className="header__inner">
        <a className="header__mark" href="#top">
          <span className="header__mark-icon" aria-hidden="true">
            <span /><span /><span />
          </span>
          <span className="header__mark-text">
            Fernwood <em>&amp;</em> Page
          </span>
        </a>

        <nav className="header__nav" aria-label="Primary">
          <ul>
            {NAV_LINKS.map((link) => (
              <li key={link}><a href="#top">{link}</a></li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
}

export default Header;
