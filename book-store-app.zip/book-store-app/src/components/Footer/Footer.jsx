﻿import "./Footer.css";

function Footer() {
  return (
    <footer className="footer">
      <div className="footer__inner">
        <div className="footer__brand">
          <span className="footer__brand-name">Fernwood &amp; Page</span>
          <p className="footer__tagline">A small shelf of books we'd hand you ourselves.</p>
        </div>

        <div className="footer__cols">
          <div className="footer__col">
            <h4>Visit</h4>
            <p>14 Elm Court, Warangal</p>
            <p>Open 10am – 8pm, daily</p>
          </div>
          <div className="footer__col">
            <h4>Contact</h4>
            <p>hello@fernwoodpage.example</p>
            <p>+91 98765 43210</p>
          </div>
          <div className="footer__col">
            <h4>Explore</h4>
            <p>New arrivals</p>
            <p>Staff picks</p>
          </div>
        </div>
      </div>
      <div className="footer__bottom">
        <span>© {new Date().getFullYear()} Fernwood &amp; Page Book Store</span>
      </div>
    </footer>
  );
}

export default Footer;
