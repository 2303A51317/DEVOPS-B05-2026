﻿import "./Rating.css";

function Rating({ value }) {
  const stars = [1, 2, 3, 4, 5];
  return (
    <div className="rating" aria-label={`Rated ${value} out of 5`}>
      <div className="rating__stars">
        {stars.map((star) => {
          const fill = Math.min(Math.max(value - (star - 1), 0), 1) * 100;
          return (
            <span className="rating__star" key={star}>
              <span className="rating__star-fill" style={{ width: `${fill}%` }}>★</span>
              <span className="rating__star-outline" aria-hidden="true">★</span>
            </span>
          );
        })}
      </div>
      <span className="rating__value">{value.toFixed(1)}</span>
    </div>
  );
}

export default Rating;
