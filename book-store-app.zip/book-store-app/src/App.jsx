﻿import { useMemo, useState } from "react";
import Header from "./components/Header/Header.jsx";
import SearchBar from "./components/SearchBar/SearchBar.jsx";
import Category from "./components/Category/Category.jsx";
import BookList from "./components/BookList/BookList.jsx";
import Footer from "./components/Footer/Footer.jsx";
import books, { categories } from "./data/books.js";
import "./App.css";

function App() {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  const [selectedBook, setSelectedBook] = useState(null);

  const visibleBooks = useMemo(() => {
    return books.filter((book) => {
      const matchesCategory = activeCategory === "All" || book.category === activeCategory;
      const matchesQuery =
        book.title.toLowerCase().includes(query.toLowerCase()) ||
        book.author.toLowerCase().includes(query.toLowerCase());
      return matchesCategory && matchesQuery;
    });
  }, [query, activeCategory]);

  return (
    <div id="top">
      <Header />

      <section className="hero">
        <div className="hero__inner">
          <h1 className="hero__title">Welcome to Online Book Store</h1>
          <p className="hero__subtitle">
            Hand-picked fiction, quiet biographies, and a few strange worlds — browse the shelf below.
          </p>
          <SearchBar value={query} onChange={setQuery} />
        </div>
      </section>

      <main className="main">
        <div className="main__inner">
          <Category categories={categories} activeCategory={activeCategory} onSelect={setActiveCategory} />
          <BookList books={visibleBooks} onViewDetails={setSelectedBook} />
        </div>
      </main>

      {selectedBook && (
        <div className="detail-overlay" onClick={() => setSelectedBook(null)}>
          <div className="detail-card" onClick={(event) => event.stopPropagation()}>
            <button type="button" className="detail-card__close" onClick={() => setSelectedBook(null)} aria-label="Close details">×</button>
            <div className="detail-card__cover" style={{ background: selectedBook.spineColor }}>
              {selectedBook.title.charAt(0)}
            </div>
            <h2>{selectedBook.title}</h2>
            <p className="detail-card__author">by {selectedBook.author}</p>
            <p className="detail-card__blurb">{selectedBook.blurb}</p>
            <div className="detail-card__meta">
              <span>{selectedBook.category}</span>
              <span>₹{selectedBook.price}</span>
              <span>★ {selectedBook.rating.toFixed(1)}</span>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}

export default App;
