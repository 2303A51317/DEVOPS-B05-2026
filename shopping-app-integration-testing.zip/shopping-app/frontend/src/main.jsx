import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";
const API = import.meta.env.VITE_API_URL || "http://localhost:5000";

function App() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState({ items: [], total: 0 });
  const [message, setMessage] = useState("Loading products...");
  const [busy, setBusy] = useState(false);

  async function request(path, options = {}) {
    const response = await fetch(`${API}${path}`, {
      ...options, headers: { "Content-Type": "application/json", ...(options.headers || {}) }
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || "Request failed");
    return data;
  }
  async function loadData() {
    try {
      const [p, c] = await Promise.all([request("/api/products"), request("/api/cart")]);
      setProducts(p); setCart(c); setMessage("");
    } catch (e) { setMessage(`Backend connection failed: ${e.message}`); }
  }
  useEffect(() => { loadData(); }, []);
  async function add(product) {
    setBusy(true);
    try { const r = await request("/api/cart", { method: "POST", body: JSON.stringify({ productId: product.id, quantity: 1 }) }); setMessage(r.message); await loadData(); }
    catch (e) { setMessage(e.message); } finally { setBusy(false); }
  }
  async function quantity(id, value) {
    if (value < 1) return;
    try { await request(`/api/cart/${id}`, { method: "PUT", body: JSON.stringify({ quantity: value }) }); await loadData(); }
    catch (e) { setMessage(e.message); }
  }
  async function remove(id) {
    try { const r = await request(`/api/cart/${id}`, { method: "DELETE" }); setMessage(r.message); await loadData(); }
    catch (e) { setMessage(e.message); }
  }
  async function checkout() {
    setBusy(true);
    try { const r = await request("/api/orders", { method: "POST", body: "{}" }); setMessage(`Order placed! Total: ₹${r.order.total.toLocaleString("en-IN")}`); await loadData(); }
    catch (e) { setMessage(e.message); } finally { setBusy(false); }
  }

  return <main className="container">
    <header><p className="eyebrow">DEMO STORE</p><h1>Online Shopping</h1><p>Browse products, manage your cart, and place an order.</p></header>
    {message && <div className="message" role="status">{message}</div>}
    <section><h2>Products</h2><div className="products">
      {products.map(p => <article className="card" key={p.id}><div className="icon">🛍️</div><h3>{p.name}</h3><p className="price">₹{p.price.toLocaleString("en-IN")}</p><button disabled={busy} onClick={() => add(p)}>Add to cart</button></article>)}
    </div></section>
    <section><h2>Your Cart</h2>
      {!cart.items.length ? <p className="empty">Your cart is empty.</p> : <>
        <div className="cart-list">{cart.items.map(item => <article className="cart-row" key={item.productId}>
          <div><strong>{item.name}</strong><p>₹{item.price.toLocaleString("en-IN")} each</p></div>
          <div className="controls"><button className="secondary" disabled={item.quantity <= 1} onClick={() => quantity(item.productId, item.quantity - 1)}>−</button><span>{item.quantity}</span><button className="secondary" onClick={() => quantity(item.productId, item.quantity + 1)}>+</button><button className="remove" onClick={() => remove(item.productId)}>Remove</button></div>
        </article>)}</div>
        <div className="checkout"><strong>Total: ₹{cart.total.toLocaleString("en-IN")}</strong><button disabled={busy} onClick={checkout}>Place order</button></div>
      </>}
    </section>
  </main>;
}
createRoot(document.getElementById("root")).render(<App />);
