const express = require("express");
const { Product, CartItem } = require("../models");
const router = express.Router();

router.post("/", async (req, res, next) => {
  try {
    const { productId, quantity = 1 } = req.body || {};
    if (!Number.isInteger(productId) || productId <= 0 || !Number.isInteger(quantity) || quantity <= 0)
      return res.status(400).json({ message: "productId and positive integer quantity are required" });
    const product = await Product.findOne({ id: productId });
    if (!product) return res.status(404).json({ message: "Product not found" });
    let item = await CartItem.findOne({ productId });
    if (item) { item.quantity += quantity; await item.save(); }
    else item = await CartItem.create({ productId: product.id, name: product.name, price: product.price, quantity });
    res.status(201).json({ message: "Product added to cart", item });
  } catch (e) { next(e); }
});
router.get("/", async (req, res, next) => {
  try {
    const items = await CartItem.find().sort({ productId: 1 }).select("-__v");
    res.json({ items, total: items.reduce((sum, item) => sum + item.price * item.quantity, 0) });
  } catch (e) { next(e); }
});
router.put("/:id", async (req, res, next) => {
  try {
    const { quantity } = req.body || {};
    if (!Number.isInteger(quantity) || quantity <= 0)
      return res.status(400).json({ message: "quantity must be a positive integer" });
    const item = await CartItem.findOneAndUpdate({ productId: Number(req.params.id) },
      { $set: { quantity } }, { new: true, runValidators: true }).select("-__v");
    if (!item) return res.status(404).json({ message: "Cart item not found" });
    res.json({ message: "Cart quantity updated", item });
  } catch (e) { next(e); }
});
router.delete("/:id", async (req, res, next) => {
  try {
    const item = await CartItem.findOneAndDelete({ productId: Number(req.params.id) });
    if (!item) return res.status(404).json({ message: "Cart item not found" });
    res.json({ message: "Product removed from cart", item });
  } catch (e) { next(e); }
});
module.exports = router;
