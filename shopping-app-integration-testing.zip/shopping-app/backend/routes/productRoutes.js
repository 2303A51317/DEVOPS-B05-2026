const express = require("express");
const { Product } = require("../models");
const router = express.Router();
router.get("/", async (req, res, next) => {
  try { res.json(await Product.find().sort({ id: 1 }).select("-__v")); } catch (e) { next(e); }
});
router.get("/:id", async (req, res, next) => {
  try {
    const product = await Product.findOne({ id: Number(req.params.id) }).select("-__v");
    if (!product) return res.status(404).json({ message: "Product not found" });
    res.json(product);
  } catch (e) { next(e); }
});
module.exports = router;
