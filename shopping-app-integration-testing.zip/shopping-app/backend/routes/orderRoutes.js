const express = require("express");
const { CartItem, Order } = require("../models");
const router = express.Router();
router.post("/", async (req, res, next) => {
  try {
    const items = await CartItem.find().sort({ productId: 1 });
    if (!items.length) return res.status(400).json({ message: "Cannot place an order with an empty cart" });
    const orderItems = items.map(item => ({
      productId: item.productId, name: item.name, price: item.price, quantity: item.quantity
    }));
    const total = orderItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const order = await Order.create({ items: orderItems, total, status: "Placed" });
    await CartItem.deleteMany({});
    res.status(201).json({ message: "Order created successfully", order });
  } catch (e) { next(e); }
});
router.get("/", async (req, res, next) => {
  try { res.json(await Order.find().sort({ createdAt: -1 }).select("-__v")); } catch (e) { next(e); }
});
module.exports = router;
