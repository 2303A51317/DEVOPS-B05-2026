const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const productRoutes = require("./routes/productRoutes");
const cartRoutes = require("./routes/cartRoutes");
const orderRoutes = require("./routes/orderRoutes");
const { Product } = require("./models");

const app = express();
const PORT = Number(process.env.PORT || 5000);
const MONGO_URI = process.env.MONGO_URI || "mongodb://127.0.0.1:27017/shopping_app";
app.use(cors());
app.use(express.json());

app.get("/health", (req, res) => res.json({
  status: mongoose.connection.readyState === 1 ? "UP" : "DEGRADED",
  service: "Shopping API",
  database: mongoose.connection.readyState === 1 ? "connected" : "disconnected"
}));
app.use("/api/products", productRoutes);
app.use("/api/cart", cartRoutes);
app.use("/api/orders", orderRoutes);
app.use((req, res) => res.status(404).json({ message: "Route not found" }));
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && "body" in err) return res.status(400).json({ message: "Invalid JSON body" });
  console.error(err);
  res.status(500).json({ message: "Internal server error" });
});

async function start() {
  await mongoose.connect(MONGO_URI);
  await Product.updateOne({ id: 101 }, { $setOnInsert: { id: 101, name: "Laptop", price: 60000 } }, { upsert: true });
  await Product.updateOne({ id: 102 }, { $setOnInsert: { id: 102, name: "Wireless Mouse", price: 1200 } }, { upsert: true });
  const server = app.listen(PORT, "0.0.0.0", () => console.log(`Shopping API listening on port ${PORT}`));
  const shutdown = async () => { server.close(); await mongoose.connection.close(); process.exit(0); };
  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
}
if (require.main === module) start().catch(err => { console.error("Failed to start:", err); process.exit(1); });
module.exports = { app, start };
