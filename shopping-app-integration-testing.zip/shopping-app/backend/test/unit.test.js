const test = require("node:test");
const assert = require("node:assert/strict");
test("sample product has expected fields", () => {
  const product = { id: 101, name: "Laptop", price: 60000 };
  assert.equal(product.id, 101);
  assert.equal(product.name, "Laptop");
  assert.equal(product.price, 60000);
  assert.ok(product.price > 0);
});
