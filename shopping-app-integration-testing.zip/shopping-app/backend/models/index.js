const mongoose = require("mongoose");
const productSchema = new mongoose.Schema({
  id: { type: Number, required: true, unique: true },
  name: { type: String, required: true },
  price: { type: Number, required: true, min: 0 }
}, { timestamps: true });
const cartItemSchema = new mongoose.Schema({
  productId: { type: Number, required: true, unique: true },
  name: { type: String, required: true },
  price: { type: Number, required: true, min: 0 },
  quantity: { type: Number, required: true, min: 1 }
}, { timestamps: true });
const orderSchema = new mongoose.Schema({
  items: [{ productId: Number, name: String, price: Number, quantity: Number }],
  total: { type: Number, required: true, min: 0 },
  status: { type: String, default: "Placed" }
}, { timestamps: true });
const Product = mongoose.models.Product || mongoose.model("Product", productSchema);
const CartItem = mongoose.models.CartItem || mongoose.model("CartItem", cartItemSchema);
const Order = mongoose.models.Order || mongoose.model("Order", orderSchema);
module.exports = { Product, CartItem, Order };
