const test = require("node:test");
const assert = require("node:assert/strict");
const BASE_URL = process.env.API_BASE_URL || "http://127.0.0.1:5000";

async function api(path, options = {}) {
  const response = await fetch(`${BASE_URL}${path}`, {
    ...options, headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const text = await response.text();
  let data = {};
  if (text) { try { data = JSON.parse(text); } catch { data = { raw: text }; } }
  return { status: response.status, data };
}

test("complete shopping workflow: products -> cart -> quantity -> order -> history", async () => {
  const products = await api("/api/products");
  assert.equal(products.status, 200);
  assert.ok(Array.isArray(products.data));
  const laptop = products.data.find(p => p.id === 101);
  assert.ok(laptop, "Laptop sample product must exist");
  assert.equal(laptop.name, "Laptop");
  assert.equal(laptop.price, 60000);

  const details = await api("/api/products/101");
  assert.equal(details.status, 200);
  assert.equal(details.data.id, 101);

  const added = await api("/api/cart", { method: "POST", body: JSON.stringify({ productId: 101, quantity: 1 }) });
  assert.equal(added.status, 201);
  assert.equal(added.data.item.quantity, 1);

  const updated = await api("/api/cart/101", { method: "PUT", body: JSON.stringify({ quantity: 2 }) });
  assert.equal(updated.status, 200);
  assert.equal(updated.data.item.quantity, 2, "quantity must be updated to 2");

  const cart = await api("/api/cart");
  assert.equal(cart.status, 200);
  assert.equal(cart.data.total, 120000, "two laptops should total 120000");
  assert.equal(cart.data.items[0].quantity, 2);

  const placed = await api("/api/orders", { method: "POST", body: JSON.stringify({}) });
  assert.equal(placed.status, 201);
  assert.equal(placed.data.order.total, 120000);
  assert.equal(placed.data.order.status, "Placed");
  assert.equal(placed.data.order.items[0].quantity, 2);

  const history = await api("/api/orders");
  assert.equal(history.status, 200);
  assert.ok(history.data.some(order => String(order._id) === String(placed.data.order._id)));
  const emptyCart = await api("/api/cart");
  assert.equal(emptyCart.data.items.length, 0);
  assert.equal(emptyCart.data.total, 0);
});

test("cart API rejects invalid quantities", async () => {
  const response = await api("/api/cart/101", { method: "PUT", body: JSON.stringify({ quantity: 0 }) });
  assert.equal(response.status, 400);
});
