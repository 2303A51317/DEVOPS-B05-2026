# Online Shopping App — Integration Testing Assignment

This project includes a React frontend, Express REST API, MongoDB persistence, integration tests, and a GitHub Actions CI workflow.

## Structure

```text
shopping-app/
├── frontend/                 # React + Vite UI
├── backend/                  # Express API + Mongoose models
├── integration-tests/        # API integration tests
└── .github/workflows/ci.yml  # GitHub Actions pipeline
```

## APIs

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/products` | Product listing |
| GET | `/api/products/:id` | Product details |
| POST | `/api/cart` | Add product to cart |
| GET | `/api/cart` | Read cart and total |
| PUT | `/api/cart/:id` | Update quantity; ID is product ID |
| DELETE | `/api/cart/:id` | Remove product |
| POST | `/api/orders` | Place order using cart |
| GET | `/api/orders` | Order history |
| GET | `/health` | Health check |

Sample product: `{"id":101,"name":"Laptop","price":60000}` is seeded at backend startup.

## Run locally

Requirements: Node.js 20+ and Docker (for MongoDB), or a local MongoDB server.

Start MongoDB:
```bash
docker run -d --name shopping-mongo -p 27017:27017 mongo:7
```

Start backend in terminal 1:
```bash
cd backend
npm install
npm run test:unit
npm start
```

Start frontend in terminal 2:
```bash
cd frontend
npm install
npm run dev
```
Open the Vite URL shown in the terminal, usually `http://localhost:5173`.

Run integration tests in terminal 3 after backend and MongoDB are running:
```bash
cd integration-tests
npm install
npm test
```

## Postman examples

Add to cart: `POST http://localhost:5000/api/cart`
```json
{"productId":101,"quantity":1}
```

Update quantity: `PUT http://localhost:5000/api/cart/101`
```json
{"quantity":2}
```

Place order: `POST http://localhost:5000/api/orders`, body `{}` as JSON.

The integration test checks product retrieval, product details, add-to-cart, quantity update, cart total, checkout, order history, and invalid quantity handling.

## CI workflow

`.github/workflows/ci.yml`:
1. Checks out code and sets up Node.js.
2. Starts an isolated MongoDB service.
3. Installs backend dependencies and runs unit tests.
4. Starts backend and waits for `/health`.
5. Runs integration tests.
6. Installs frontend dependencies and builds React.
7. Uploads the frontend `dist` artifact.

It runs on pushes and pull requests to `main` or `master`, and can be triggered manually.

## Demonstrate failure and fix

Temporarily break quantity update in `backend/routes/cartRoutes.js` by changing:
```js
{ $set: { quantity } }
```
to:
```js
{ $set: { quantity: 1 } }
```
The integration test should fail because it expects quantity `2`. Restore `{ $set: { quantity } }`, commit and push the fix; the tests and frontend build should pass. The CI job stops at the failing step, so frontend build is skipped while integration tests fail.

## Database notes

CI uses a dedicated `shopping_app_test` database on an ephemeral MongoDB service. Orders, cart items, and products are stored in MongoDB. This is an educational starter; a production application should add authentication, authorization, robust validation, logging, secrets management, and payment provider safeguards.
