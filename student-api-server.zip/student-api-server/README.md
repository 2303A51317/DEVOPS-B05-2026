# Secure Student Management API

A Node.js + Express REST API with JWT authentication for a College Student Management Application.

## Technologies

- Node.js
- Express
- JSON Web Token (jsonwebtoken)
- Nodemon
- Postman / Thunder Client

## Project Structure

```text
student-api-server/
├── middleware/
│   ├── admin.js
│   └── auth.js
├── package.json
├── README.md
└── server.js
```

## 1. Install Dependencies

Open the terminal inside this folder:

```bash
npm install
```

## 2. Start the Server

Normal mode:

```bash
npm start
```

Development mode with Nodemon:

```bash
npm run dev
```

Server URL:

```text
http://localhost:3000
```

## 3. Register a Student User

### POST

```text
http://localhost:3000/register
```

Body -> raw -> JSON:

```json
{
  "username": "student1",
  "password": "1234",
  "role": "student"
}
```

## 4. Register an Admin User

```json
{
  "username": "admin1",
  "password": "admin123",
  "role": "admin"
}
```

> The role field is included for the bonus role-based authentication requirement.

## 5. Login

### POST

```text
http://localhost:3000/login
```

Body:

```json
{
  "username": "student1",
  "password": "1234"
}
```

The response contains a JWT token:

```json
{
  "message": "Login successful",
  "token": "YOUR_JWT_TOKEN",
  "expiresIn": "1h"
}
```

Copy the token.

## 6. Access Protected Students API

### GET

```text
http://localhost:3000/students
```

Headers:

```text
Authorization: Bearer YOUR_JWT_TOKEN
```

The token is required.

## 7. Get Student by ID

### GET

```text
http://localhost:3000/students/1
```

Header:

```text
Authorization: Bearer YOUR_JWT_TOKEN
```

## 8. Add Student

Only an admin JWT can add a student.

### POST

```text
http://localhost:3000/students
```

Header:

```text
Authorization: Bearer ADMIN_JWT_TOKEN
Content-Type: application/json
```

Body:

```json
{
  "name": "Anjali",
  "age": 20,
  "course": "CSE",
  "year": 3
}
```

## 9. Delete Student

Only an admin JWT can delete a student.

### DELETE

```text
http://localhost:3000/students/3
```

Header:

```text
Authorization: Bearer ADMIN_JWT_TOKEN
```

## 10. Test Unauthorized Requests

### Without token

Request:

```text
GET http://localhost:3000/students
```

Expected:

```json
{
  "error": "Unauthorized",
  "message": "Authorization header is missing"
}
```

Status:

```text
401 Unauthorized
```

### Invalid token

Use:

```text
Authorization: Bearer abc123
```

Expected status:

```text
401 Unauthorized
```

### Expired token

Login, wait until the configured JWT expiration time, and call `/students`.

Expected status:

```text
401 Unauthorized
```

## API Summary

| Method | Endpoint | Authentication | Access |
|---|---|---|---|
| GET | / | No | Everyone |
| POST | /register | No | Everyone |
| POST | /login | No | Everyone |
| GET | /students | JWT | Student/Admin |
| GET | /students/:id | JWT | Student/Admin |
| POST | /students | JWT + Admin | Admin only |
| DELETE | /students/:id | JWT + Admin | Admin only |

## Important

This project stores users and students in arrays as required by the assignment. Passwords are intentionally kept simple for classroom demonstration. In a real application, use password hashing such as bcrypt and store data in a database.

The JWT secret is also placed directly in the source for this assignment. In production, use an environment variable such as `process.env.JWT_SECRET`.
