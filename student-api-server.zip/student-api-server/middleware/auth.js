const jwt = require("jsonwebtoken");

const JWT_SECRET = "student_api_secret_2026";

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return res.status(401).json({
      error: "Unauthorized",
      message: "Authorization header is missing"
    });
  }

  const parts = authHeader.split(" ");

  if (parts.length !== 2 || parts[0] !== "Bearer") {
    return res.status(401).json({
      error: "Unauthorized",
      message: "Use Authorization: Bearer <JWT_TOKEN>"
    });
  }

  const token = parts[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      return res.status(401).json({
        error: "Unauthorized",
        message: "JWT token has expired"
      });
    }

    return res.status(401).json({
      error: "Unauthorized",
      message: "Invalid JWT token"
    });
  }
}

module.exports = authMiddleware;