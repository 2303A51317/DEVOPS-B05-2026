function adminMiddleware(req, res, next) {
  if (!req.user || req.user.role !== "admin") {
    return res.status(403).json({
      error: "Forbidden",
      message: "Only admin users can perform this operation"
    });
  }

  next();
}

module.exports = adminMiddleware;