const express = require("express");
const jwt = require("jsonwebtoken");

const authMiddleware = require("./middleware/auth");
const adminMiddleware = require("./middleware/admin");

const app = express();
const PORT = 3000;
const JWT_SECRET = "student_api_secret_2026";
const JWT_EXPIRES_IN = "1h";

// In-memory storage for the assignment
const users = [];
let students = [
  { id: 1, name: "Swetha", age: 20, course: "CSE", year: 3 },
  { id: 2, name: "Rahul", age: 21, course: "CSE", year: 3 }
];

// Middleware
app.use(express.json());

app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.originalUrl}`);
  next();
});

// Home
app.get("/", (req, res) => {
  res.status(200).json({
    message: "Welcome to Secure Student API"
  });
});

// Register
app.post("/register", (req, res) => {
  const { username, password, role = "student" } = req.body;

  if (!username || !password) {
    return res.status(400).json({
      error: "Username and password are required"
    });
  }

  if (username.length < 3 || password.length < 4) {
    return res.status(400).json({
      error: "Username must have at least 3 characters and password at least 4 characters"
    });
  }

  const existingUser = users.find(
    (user) => user.username.toLowerCase() === username.toLowerCase()
  );

  if (existingUser) {
    return res.status(409).json({
      error: "Username already exists"
    });
  }

  const safeRole = role === "admin" ? "admin" : "student";

  // For this classroom assignment, users are stored in memory.
  // In a real application, passwords must be hashed before storage.
  const newUser = {
    id: users.length + 1,
    username,
    password,
    role: safeRole
  };

  users.push(newUser);

  res.status(201).json({
    message: "User registered successfully",
    user: {
      id: newUser.id,
      username: newUser.username,
      role: newUser.role
    }
  });
});

// Login
app.post("/login", (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({
      error: "Username and password are required"
    });
  }

  const user = users.find(
    (item) => item.username === username && item.password === password
  );

  if (!user) {
    return res.status(401).json({
      error: "Invalid username or password"
    });
  }

  const token = jwt.sign(
    {
      userId: user.id,
      username: user.username,
      role: user.role
    },
    JWT_SECRET,
    {
      expiresIn: JWT_EXPIRES_IN
    }
  );

  res.status(200).json({
    message: "Login successful",
    token,
    expiresIn: JWT_EXPIRES_IN,
    user: {
      id: user.id,
      username: user.username,
      role: user.role
    }
  });
});

// Protected: get all students
app.get("/students", authMiddleware, (req, res) => {
  res.status(200).json({
    count: students.length,
    students
  });
});

// Protected: get one student
app.get("/students/:id", authMiddleware, (req, res) => {
  const id = Number(req.params.id);

  if (!Number.isInteger(id)) {
    return res.status(400).json({
      error: "Student id must be a number"
    });
  }

  const student = students.find((item) => item.id === id);

  if (!student) {
    return res.status(404).json({
      error: "Student not found"
    });
  }

  res.status(200).json(student);
});

// Protected + admin: add student
app.post("/students", authMiddleware, adminMiddleware, (req, res) => {
  const { name, age, course, year } = req.body;

  if (!name || age === undefined || !course || year === undefined) {
    return res.status(400).json({
      error: "name, age, course and year are required"
    });
  }

  const ageNumber = Number(age);
  const yearNumber = Number(year);

  if (!Number.isFinite(ageNumber) || !Number.isInteger(yearNumber)) {
    return res.status(400).json({
      error: "age and year must be valid numbers"
    });
  }

  const newStudent = {
    id: students.length
      ? Math.max(...students.map((student) => student.id)) + 1
      : 1,
    name,
    age: ageNumber,
    course,
    year: yearNumber
  };

  students.push(newStudent);

  res.status(201).json({
    message: "Student added successfully",
    student: newStudent
  });
});

// Bonus: protected + admin delete
app.delete("/students/:id", authMiddleware, adminMiddleware, (req, res) => {
  const id = Number(req.params.id);

  if (!Number.isInteger(id)) {
    return res.status(400).json({
      error: "Student id must be a number"
    });
  }

  const index = students.findIndex((student) => student.id === id);

  if (index === -1) {
    return res.status(404).json({
      error: "Student not found"
    });
  }

  const deletedStudent = students.splice(index, 1)[0];

  res.status(200).json({
    message: "Student deleted successfully",
    student: deletedStudent
  });
});

// 404 middleware
app.use((req, res) => {
  res.status(404).json({
    error: "Route not found"
  });
});

// General error middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    error: "Internal server error"
  });
});

app.listen(PORT, () => {
  console.log("======================================");
  console.log(" Secure Student Management API");
  console.log("======================================");
  console.log(`Server running at http://localhost:${PORT}`);
  console.log(`JWT expiration: ${JWT_EXPIRES_IN}`);
  console.log("Use Ctrl+C to stop the server");
});